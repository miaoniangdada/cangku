// pages/text/text.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    src: "http://193.112.34.102:8080/pict/123.jpg",
    state: "进行中",
    title: "广东工业大学小程序大赛",
    club: "计算机团委",
    activitytime: "2019年4月21日",
    timelong: "20h"

  },

  show: function () {
    wx.showModal({
      title: '广东工业大学小程序大赛',
      content: '组织：计算机团委 活动时间：2019年4月21日 时长：2h   活动介绍：进行中  大佬们很强 萌新瑟瑟发抖',

    })
  },
})
