// pages/text/text.js
Page({

  data: {
    result: '1',
    state: '1',
    aresult: 'a',
    atitle: '1',
    name:'雨伞',
    where:'教三205',
    time:'2019-4-11',
    des:'一把helloketty的伞'
  },
  data: {
    "imgUrls": [
      "http://193.112.34.102:8080/pict/abc.jpg",
      "http://193.112.34.102:8080/pict/121.jpg",
      "http://193.112.34.102:8080/pict/122.jpg",
      "http://193.112.34.102:8080/pict/123.jpg"
    ],
    navbar: ['杂七杂八', '丢三落四'],
    currentTab: 0 ,
    sercherStorage: [],
    inputValue: "",             //搜索框输入的值  
    StorageFlag: false,         //显示搜索记录标志位
    focus: false,
    inputValue: ''
  },
 
  gotosearch: function () {
    wx.switchTab({
      url: '../find/find'
    })},
  gotonew: function () {
    wx.navigateTo({
      url: '../new/new'
    })
  },
  gotocommand: function () {
    wx.navigateTo({
      url: '../command/command'
    })
  },
  gotofollow: function () {
    wx.navigateTo({
      url: '../follow/follow'
    })
  },
  gotoapply: function () {
    wx.showModal({
      title: '抱歉',
      content: '活动申请接口暂未开发~',

    })
  },
  
  onLoad: function () {
    console.log('onLoad')
    var that = this;
    wx.request({
      url: '',
      header: {
        'content-type': 'application/json'
      },
      //请求后台数据成功
      success: function (res) {
        console.log('返回的code' + res.data.code)
        console.log('返回的id' + res.data.message)
        that.setData({
          motto: '后台返回code:' + res.data.code + '\n后台返回的message:' + res.data.message
        })
      }
    })

  },
  navbarTap: function (e) {
    this.setData({
      currentTab: e.currentTarget.dataset.idx
    })
  },
  bindButtonTap: function () {
    this.setData({
      focus: true
    })
  },

})