// pages/text/text.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    src: "http://193.112.34.102:8080/pict/121.jpg",
    state:"进行中",
    title: "医疗知识竞赛",
    club: "计算机院红会",
    activitytime: "2019年4月29日",
    timelong:"6h"

  },


  show: function () {
    wx.showModal({
      title: '医疗知识竞赛',
      activitytime: "2019年4月29日",
      content: '组织：计算机院红会 活动时间：2019年4月22日 时长：6h   活动介绍：你想展现你的医疗知识水平么~或者你想学习相关知识么  赶快报名吧~',

    })
  },
})
