//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
    welcome: "点击开启新世界~",
    
  },
  //事件处理函数
  bindViewTap: function() {
    wx.switchTab({
      url: '../search/search'
    })
  },
  onLoad: function () {
    console.log('onLoad')
  }
})
