// pages/text/text.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    src: "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=2027730583,192519566&fm=27&gp=0.jpg",
    state:"已结束",
    title: "土木毕业照",
    club: "土木学院",
    activitytime: "2019年4月22日",
    timelong:"2h"

  },

  
  show: function () {
    wx.showModal({
      title: '土木毕业照',
      content: '组织：土木学院 活动时间：2019年4月22日 时长：2h   活动介绍：一年一次的毕业照  有认识的师兄师姐无妨去看看 顺便合个影~~',

    })
  },
})
