// pages/text/text.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
 
  },
show:function(){
  wx.showModal({
    title: '关于我们',
    content: '版权所有：西一602  邮箱联系：416043959@qq.com',
    
  })
  }, show2: function () {
    wx.showModal({
      title: 'emmmm',
      content: '不知道要设置什么呢  试试在关于那里找到我们吧~',

    })
  }, show3: function () {
    wx.showModal({
      title: '提建议~',
      content: '因为还不是正式版  试试在关于那里找到我们吧~',

    })
  },
  gotofollow: function () {
    wx.navigateTo({
      url: '../follow/follow'
    })
  },
  gotolost: function () {
    wx.navigateTo({
      url: '../lost/lost'
    })
  },
  onLoad: function () {
   
      wx.showModal({
        title: '来自制作团队的祝福',
        content: '祝你天天快乐~ 万事如意',

      })
  }, 
  lose: function () {

    wx.switchTab({
        url: '../search/search'
      })

  },
})